import { http } from '@/lib/api/http';
import { TradingAnalysis } from '@/lib/types';

export async function analyzeSymbol(symbol: string) {
  return http<TradingAnalysis>('/api/ai/trading/analyze', {
    method: 'POST',
    body: JSON.stringify({ symbol })
  });
}

export async function generateTradingPlan(symbol: string) {
  return http<TradingAnalysis>('/api/ai/trading/analyze', {
    method: 'POST',
    body: JSON.stringify({ symbol, mode: 'extended_plan' })
  });
}
