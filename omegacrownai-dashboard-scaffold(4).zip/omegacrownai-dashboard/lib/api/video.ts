import { http } from '@/lib/api/http';
import { VideoJob } from '@/lib/types';

export async function generateVideo(payload: { prompt: string; duration: number; style: string; resolution: string }) {
  return http<VideoJob>('/api/ai/video/generate', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

export async function getVideoStatus(jobId: string) {
  return http<VideoJob>(`/api/ai/video/status?job_id=${jobId}`);
}
