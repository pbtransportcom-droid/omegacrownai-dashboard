import { http } from '@/lib/api/http';
import { WorkflowView } from '@/lib/types';

export async function generateWorkflow(instruction: string) {
  return http<WorkflowView>('/api/ai/workflow/generate', {
    method: 'POST',
    body: JSON.stringify({ instruction })
  });
}
