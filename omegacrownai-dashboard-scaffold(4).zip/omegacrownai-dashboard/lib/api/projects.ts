import { http } from '@/lib/api/http';
import { ProjectSummary } from '@/lib/types';

export async function getProjects() {
  return http<ProjectSummary[]>('/api/projects/list');
}
