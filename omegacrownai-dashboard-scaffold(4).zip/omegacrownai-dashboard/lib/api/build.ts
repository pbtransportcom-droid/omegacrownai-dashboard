import { http } from '@/lib/api/http';

export async function createWebsite(description: string, framework = 'nextjs-tailwind') {
  return http<{ files: { name: string; content: string }[]; preview_url?: string }>('/api/ai/website/build', {
    method: 'POST',
    body: JSON.stringify({ description, framework, project_id: 'auto' })
  });
}

export async function createApp(description: string, framework = 'react-node') {
  const spec = await http<any>('/api/ai/app/spec', {
    method: 'POST',
    body: JSON.stringify({ description })
  });

  return http<{ files: { name: string; content: string }[] }>('/api/ai/app/generate', {
    method: 'POST',
    body: JSON.stringify({ spec, framework, project_id: 'auto' })
  });
}
