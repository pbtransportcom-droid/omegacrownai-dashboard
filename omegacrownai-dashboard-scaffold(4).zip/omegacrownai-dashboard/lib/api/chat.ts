import { http } from '@/lib/api/http';
import { AIChatRequest, ChatResponse } from '@/lib/types';

export async function sendChat(payload: AIChatRequest) {
  return http<ChatResponse>('/api/ai/chat', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}
