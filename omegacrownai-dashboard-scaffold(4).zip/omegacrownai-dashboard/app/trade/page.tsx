import { AppShell } from '@/components/layout/AppShell';
import { SectionHeader } from '@/components/layout/SectionHeader';
import { TradeWorkspace } from '@/components/trade/TradeWorkspace';

export default function TradePage() {
  return (
    <AppShell section="trade">
      <SectionHeader eyebrow="Trade" title="Trading AI dashboard" subtitle="Watchlist, chart area, and right-rail AI analysis connected to /api/ai/trading/analyze." />
      <TradeWorkspace />
    </AppShell>
  );
}
