import { AppShell } from '@/components/layout/AppShell';
import { SectionHeader } from '@/components/layout/SectionHeader';
import { ProjectsTable } from '@/components/projects/ProjectsTable';

export default function ProjectsPage() {
  return (
    <AppShell section="projects">
      <SectionHeader eyebrow="Projects" title="Project manager" subtitle="Cross-module project list that routes users into the correct workspace based on project type." />
      <ProjectsTable />
    </AppShell>
  );
}
