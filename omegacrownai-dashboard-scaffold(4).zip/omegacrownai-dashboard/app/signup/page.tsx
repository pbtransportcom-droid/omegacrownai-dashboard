import Link from 'next/link';
import { Button } from '@/components/common/Button';
import { Card } from '@/components/common/Card';
import { Input } from '@/components/common/Input';

export default function SignupPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-bg p-6">
      <Card>
        <div className="w-full max-w-md space-y-4">
          <h1 className="text-2xl font-semibold">Create account</h1>
          <Input placeholder="Name" />
          <Input placeholder="Email" />
          <Input placeholder="Password" type="password" />
          <Button className="w-full">Create account</Button>
          <p className="text-sm text-muted">Already have an account? <Link href="/login">Login</Link></p>
        </div>
      </Card>
    </div>
  );
}
