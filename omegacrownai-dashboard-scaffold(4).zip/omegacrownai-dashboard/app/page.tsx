import Link from 'next/link';
import { AppShell } from '@/components/layout/AppShell';
import { SectionHeader } from '@/components/layout/SectionHeader';
import { Card } from '@/components/common/Card';

const quickActions = [
  { title: 'Create Website', href: '/build/website/web-001' },
  { title: 'Generate Video', href: '/create' },
  { title: 'Analyze Market', href: '/trade' },
  { title: 'Create Automation', href: '/automate' }
];

export default function HomePage() {
  return (
    <AppShell section="chat">
      <SectionHeader
        eyebrow="Dashboard"
        title="OmegaCrownAI command center"
        subtitle="Unified workspace for build, trade, create, automate, projects, and AI chat."
      />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <h3 className="font-semibold">Quick actions</h3>
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {quickActions.map((item) => (
              <Link key={item.title} href={item.href} className="rounded-2xl border border-border bg-black/20 p-4 text-sm text-muted transition hover:bg-white/5 hover:text-text">
                {item.title}
              </Link>
            ))}
          </div>
        </Card>
        <Card>
          <h3 className="font-semibold">What this scaffold includes</h3>
          <ul className="mt-4 space-y-3 text-sm text-muted">
            <li>• App Router pages for all primary modules</li>
            <li>• Shared shell, sidebar, and top nav</li>
            <li>• Typed API client wrappers for backend contracts</li>
            <li>• Starter UIs for trade, video, build, automate, projects, and chat</li>
          </ul>
        </Card>
      </div>
    </AppShell>
  );
}
