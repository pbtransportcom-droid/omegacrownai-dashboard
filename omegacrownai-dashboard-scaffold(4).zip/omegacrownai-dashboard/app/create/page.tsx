import { CreateWorkspace } from '@/components/create/CreateWorkspace';
import { AppShell } from '@/components/layout/AppShell';
import { SectionHeader } from '@/components/layout/SectionHeader';

export default function CreatePage() {
  return (
    <AppShell section="create">
      <SectionHeader eyebrow="Create" title="Video generation workspace" subtitle="Prompt, controls, job list, and player wired for /api/ai/video/generate and status polling." />
      <CreateWorkspace />
    </AppShell>
  );
}
