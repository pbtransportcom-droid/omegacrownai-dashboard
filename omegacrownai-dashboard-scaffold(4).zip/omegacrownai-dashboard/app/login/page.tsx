import Link from 'next/link';
import { Button } from '@/components/common/Button';
import { Card } from '@/components/common/Card';
import { Input } from '@/components/common/Input';

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-bg p-6">
      <Card>
        <div className="w-full max-w-md space-y-4">
          <h1 className="text-2xl font-semibold">Login</h1>
          <Input placeholder="Email" />
          <Input placeholder="Password" type="password" />
          <Button className="w-full">Continue</Button>
          <div className="flex justify-between text-sm text-muted">
            <Link href="/signup">Create account</Link>
            <Link href="/forgot-password">Forgot password</Link>
          </div>
        </div>
      </Card>
    </div>
  );
}
