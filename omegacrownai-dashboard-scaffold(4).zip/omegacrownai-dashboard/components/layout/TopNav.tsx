'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Bot, Boxes, Film, FolderOpen, LineChart, Workflow } from 'lucide-react';
import { Badge } from '@/components/common/Badge';

const nav = [
  { href: '/build', label: 'Build', icon: Boxes },
  { href: '/trade', label: 'Trade', icon: LineChart },
  { href: '/create', label: 'Create', icon: Film },
  { href: '/automate', label: 'Automate', icon: Workflow },
  { href: '/projects', label: 'Projects', icon: FolderOpen },
  { href: '/chat', label: 'Chat', icon: Bot }
];

export function TopNav() {
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-20 border-b border-border bg-bg/80 backdrop-blur">
      <div className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center gap-4">
          <Link href="/" className="text-lg font-semibold tracking-tight">OmegaCrownAI</Link>
          <Badge>dashboard v1</Badge>
        </div>

        <nav className="hidden gap-1 md:flex">
          {nav.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || pathname.startsWith(`${href}/`);
            return (
              <Link
                key={href}
                href={href}
                className={`inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm transition ${active ? 'bg-white/8 text-text' : 'text-muted hover:bg-white/5 hover:text-text'}`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden text-right sm:block">
            <p className="text-sm font-medium">Pb Transportation</p>
            <p className="text-xs text-muted">Enterprise plan</p>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent font-semibold">PB</div>
        </div>
      </div>
    </header>
  );
}
