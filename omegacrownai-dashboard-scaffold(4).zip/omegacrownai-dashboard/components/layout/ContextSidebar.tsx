import Link from 'next/link';
import { mockProjects } from '@/lib/mock-data';

const content: Record<string, { title: string; items: { label: string; href: string }[] }> = {
  build: {
    title: 'Build tools',
    items: [
      { label: 'Websites', href: '/build' },
      { label: 'Website workspace', href: '/build/website/web-001' },
      { label: 'App workspace', href: '/build/app/app-002' }
    ]
  },
  trade: {
    title: 'Watchlist',
    items: ['AAPL', 'TSLA', 'BTCUSDT', 'ETHUSDT'].map((symbol) => ({ label: symbol, href: `/trade?symbol=${symbol}` }))
  },
  create: {
    title: 'Recent renders',
    items: [
      { label: 'Market recap', href: '/create' },
      { label: 'Brand trailer', href: '/create' }
    ]
  },
  automate: {
    title: 'Automation',
    items: [
      { label: 'BTC alert', href: '/automate' },
      { label: 'Daily recap', href: '/automate' }
    ]
  },
  projects: {
    title: 'Project shortcuts',
    items: mockProjects.map((project) => ({ label: project.name, href: '/projects' }))
  },
  chat: {
    title: 'Context',
    items: [
      { label: 'No project', href: '/chat' },
      { label: 'OmegaCrown Landing Page', href: '/chat?projectId=web-001' },
      { label: 'Signal Dashboard', href: '/chat?projectId=app-002' }
    ]
  }
};

export function ContextSidebar({ section }: { section: keyof typeof content }) {
  const config = content[section];

  return (
    <aside className="hidden w-72 shrink-0 border-r border-border lg:block">
      <div className="space-y-4 p-5">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted">Section</p>
          <h2 className="section-title mt-1">{config.title}</h2>
        </div>

        <div className="space-y-2">
          {config.items.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className="block rounded-xl border border-border bg-white/3 px-3 py-2.5 text-sm text-muted transition hover:bg-white/5 hover:text-text"
            >
              {item.label}
            </Link>
          ))}
        </div>
      </div>
    </aside>
  );
}
